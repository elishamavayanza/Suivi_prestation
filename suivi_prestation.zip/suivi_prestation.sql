-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le : mar. 25 nov. 2025 à 12:19
-- Version du serveur : 8.2.0
-- Version de PHP : 8.2.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `suivi_prestation`
--

-- --------------------------------------------------------

--
-- Structure de la table `annee`
--

DROP TABLE IF EXISTS `annee`;
CREATE TABLE IF NOT EXISTS `annee` (
  `code_annee` int NOT NULL AUTO_INCREMENT,
  `dt_debut` date NOT NULL,
  `dt_fin` date NOT NULL,
  `description` varchar(255) NOT NULL,
  PRIMARY KEY (`code_annee`)
) ENGINE=InnoDB AUTO_INCREMENT=2 ;

-- --------------------------------------------------------

--
-- Structure de la table `chargehoraire`
--

DROP TABLE IF EXISTS `chargehoraire`;
CREATE TABLE IF NOT EXISTS `chargehoraire` (
  `id` int NOT NULL AUTO_INCREMENT,
  `matricule` varchar(50) DEFAULT NULL,
  `codecours` varchar(50) DEFAULT NULL,
  `codepromotion` varchar(10) DEFAULT NULL,
  `observation` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 ;

--
-- Déchargement des données de la table `chargehoraire`
--

INSERT INTO `chargehoraire` (`id`, `matricule`, `codecours`, `codepromotion`, `observation`) VALUES
(1, 'E0001', '2', '5', 'ok'),
(2, 'E0001', '3', '5', 'ok');

-- --------------------------------------------------------

--
-- Structure de la table `contenufiche`
--

DROP TABLE IF EXISTS `contenufiche`;
CREATE TABLE IF NOT EXISTS `contenufiche` (
  `id` int NOT NULL AUTO_INCREMENT,
  `identetefiche` int DEFAULT NULL,
  `datejoure` date DEFAULT NULL,
  `contenu` text,
  `heureEntree` time DEFAULT NULL,
  `heureSortie` time DEFAULT NULL,
  `nbreH` double DEFAULT NULL,
  `signatureCP` varchar(4) DEFAULT NULL,
  `signatureEnseignant` varchar(8) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 ;

--
-- Déchargement des données de la table `contenufiche`
--

INSERT INTO `contenufiche` (`id`, `identetefiche`, `datejoure`, `contenu`, `heureEntree`, `heureSortie`, `nbreH`, `signatureCP`, `signatureEnseignant`) VALUES
(1, 1, '2025-11-20', 'Introduction du cours', '14:00:00', '17:30:00', 3, 'ok', 'ok'),
(2, 1, '2025-11-20', 'Ordinateur avec ses composant', '14:00:00', '17:30:00', 3, 'ok', 'ok');

-- --------------------------------------------------------

--
-- Structure de la table `cours`
--

DROP TABLE IF EXISTS `cours`;
CREATE TABLE IF NOT EXISTS `cours` (
  `id` int NOT NULL AUTO_INCREMENT,
  `code_cours` varchar(50) NOT NULL,
  `nomComplet` varchar(255) NOT NULL,
  `nbreHeure` int NOT NULL,
  `ponderation` int NOT NULL,
  `code_mention` int NOT NULL,
  `code_section` int DEFAULT NULL,
  `dtsave` datetime DEFAULT CURRENT_TIMESTAMP,
  `promotion` varchar(50) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code_cours` (`code_cours`),
  KEY `code_mention` (`code_mention`,`code_section`)
) ENGINE=InnoDB AUTO_INCREMENT=5 ;

--
-- Déchargement des données de la table `cours`
--

INSERT INTO `cours` (`id`, `code_cours`, `nomComplet`, `nbreHeure`, `ponderation`, `code_mention`, `code_section`, `dtsave`, `promotion`, `description`) VALUES
(2, 'IG1', 'Informatic Generale', 90, 120, 2, 2, '2025-11-18 12:35:02', '5', 'Informatic Generale'),
(3, 'AL1', 'Algorithmic', 90, 120, 2, 2, '2025-11-18 12:38:41', '5', 'Algorithmic introduction a la programmation'),
(4, 'FR1', 'Francais', 75, 100, 2, 2, '2025-11-18 12:41:10', '5', 'Francais generale');

-- --------------------------------------------------------

--
-- Structure de la table `coursfini`
--

DROP TABLE IF EXISTS `coursfini`;
CREATE TABLE IF NOT EXISTS `coursfini` (
  `id` int NOT NULL AUTO_INCREMENT,
  `code_section` int DEFAULT NULL,
  `code_mention` int DEFAULT NULL,
  `code_promotion` varchar(50) DEFAULT NULL,
  `code_cours` varchar(50) DEFAULT NULL,
  `matricule_enseignant` varchar(50) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `datesave` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM ;

-- --------------------------------------------------------

--
-- Structure de la table `descriptionfiche`
--

DROP TABLE IF EXISTS `descriptionfiche`;
CREATE TABLE IF NOT EXISTS `descriptionfiche` (
  `id` int NOT NULL AUTO_INCREMENT,
  `code_section` int DEFAULT NULL,
  `code_mention` int DEFAULT NULL,
  `code_promotion` varchar(50) DEFAULT NULL,
  `code_cours` varchar(10) DEFAULT NULL,
  `matricule_enseignant` varchar(50) DEFAULT NULL,
  `dt` date DEFAULT NULL,
  `objectif` varchar(255) DEFAULT NULL,
  `contenu` text,
  `methode` varchar(255) DEFAULT NULL,
  `ressource` varchar(255) DEFAULT NULL,
  `nature` varchar(255) DEFAULT NULL,
  `evaluation` varchar(255) DEFAULT NULL,
  `bibliographie` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2;

--
-- Déchargement des données de la table `descriptionfiche`
--

INSERT INTO `descriptionfiche` (`id`, `code_section`, `code_mention`, `code_promotion`, `code_cours`, `matricule_enseignant`, `dt`, `objectif`, `contenu`, `methode`, `ressource`, `nature`, `evaluation`, `bibliographie`) VALUES
(1, 2, 2, '5', '2', 'E0001', '0000-00-00', '', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Structure de la table `enseignant`
--

DROP TABLE IF EXISTS `enseignant`;
CREATE TABLE IF NOT EXISTS `enseignant` (
  `matriculeEnseignant` varchar(50) NOT NULL,
  `nom` varchar(50) NOT NULL,
  `postnom` varchar(50) NOT NULL,
  `prenom` varchar(50) NOT NULL,
  `genre` varchar(10) NOT NULL,
  `dtnaissance` date NOT NULL,
  `nationalite` varchar(50) NOT NULL,
  `etatCivil` varchar(50) NOT NULL,
  `adresse` varchar(255) NOT NULL,
  `adresseMail` varchar(255) NOT NULL,
  `telephone` varchar(50) NOT NULL,
  `grade` varchar(255) NOT NULL,
  `domainEnseignant` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `dtsave` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`matriculeEnseignant`)
) ENGINE=MyISAM ;

--
-- Déchargement des données de la table `enseignant`
--

INSERT INTO `enseignant` (`matriculeEnseignant`, `nom`, `postnom`, `prenom`, `genre`, `dtnaissance`, `nationalite`, `etatCivil`, `adresse`, `adresseMail`, `telephone`, `grade`, `domainEnseignant`, `dtsave`) VALUES
('E0001', 'Kakule', 'TABALIRA', 'ZACHARIE', 'masculn', '2025-10-30', 'Marie', 'Congolaise', 'Ngule', 'zacharietabalira@gmal.com', '0987654321', 'Ass', 'Informatique', '2025-11-13 13:34:29'),
('E0002', 'Kakule', 'Kagheni', 'Kagheni', 'masculn', '1996-10-20', 'marie', 'Congolaise', 'Kisingiri', 'kagheni@gmail.com', '0974868655', 'Ass', 'Informatique', '2025-11-20 10:01:36');

-- --------------------------------------------------------

--
-- Structure de la table `entetefiche`
--

DROP TABLE IF EXISTS `entetefiche`;
CREATE TABLE IF NOT EXISTS `entetefiche` (
  `id` int NOT NULL AUTO_INCREMENT,
  `code_section` int DEFAULT NULL,
  `code_mention` int DEFAULT NULL,
  `code_promotion` varchar(50) DEFAULT NULL,
  `code_cours` varchar(50) DEFAULT NULL,
  `matricule_enseignant` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 ;

--
-- Déchargement des données de la table `entetefiche`
--

INSERT INTO `entetefiche` (`id`, `code_section`, `code_mention`, `code_promotion`, `code_cours`, `matricule_enseignant`) VALUES
(1, 2, 2, '5', '2', 'E0001'),
(2, 2, 2, '5', '2', 'E0001');

-- --------------------------------------------------------

--
-- Structure de la table `etudiant`
--

DROP TABLE IF EXISTS `etudiant`;
CREATE TABLE IF NOT EXISTS `etudiant` (
  `matriculeEtudiant` varchar(50) NOT NULL,
  `nom` varchar(50) NOT NULL,
  `postnom` varchar(50) NOT NULL,
  `prenom` varchar(50) NOT NULL,
  `genre` varchar(10) NOT NULL,
  `dtnaissance` date NOT NULL,
  `nationalite` varchar(50) NOT NULL,
  `etatCivil` varchar(50) NOT NULL,
  `adresse` varchar(255) NOT NULL,
  `adresseMail` varchar(255) NOT NULL,
  `telephone` varchar(50) NOT NULL,
  `dt_save` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`matriculeEtudiant`)
) ENGINE=InnoDB ;

--
-- Déchargement des données de la table `etudiant`
--

INSERT INTO `etudiant` (`matriculeEtudiant`, `nom`, `postnom`, `prenom`, `genre`, `dtnaissance`, `nationalite`, `etatCivil`, `adresse`, `adresseMail`, `telephone`, `dt_save`) VALUES
('A', 'k', 'l', 'l', 'masculn', '2000-08-09', 'u', 'u', 'u', 'uiy', '09', '2025-08-29 15:04:33'),
('A23', 'i', 'I', 'o', 'masculn', '2000-02-02', 'j', 'j', 'j', 'iou', '098', '2025-08-29 15:05:22'),
('AAA1', 'Kate', 'SiKwa', 'Chris', 'masculn', '2025-08-23', 'Celi', 'congo', 'Saba', 'chrimeaux@gmail.com', '098766', '2025-08-29 14:53:56'),
('AAA2', 'j', 'j', 'j', 'masculn', '2025-08-16', 'p', 'k', 'k', 'iioi', '0098', '2025-08-29 15:01:21'),
('Aaab', 'j', 'k', 'k', 'masculn', '2000-07-07', 'h', 'v', 'g', 'hjg', '098', '2025-08-30 07:53:11'),
('WER34', 'hj', 'jkk', 'kk', 'masculn', '1999-08-02', 'c', 'c', 's', 'rf', '0987', '2025-08-31 01:40:31');

-- --------------------------------------------------------

--
-- Structure de la table `honoraire`
--

DROP TABLE IF EXISTS `honoraire`;
CREATE TABLE IF NOT EXISTS `honoraire` (
  `id` int NOT NULL AUTO_INCREMENT,
  `code_section` int DEFAULT NULL,
  `code_mention` int DEFAULT NULL,
  `code_promotion` varchar(50) DEFAULT NULL,
  `code_cours` varchar(50) DEFAULT NULL,
  `matricule_enseignant` varchar(50) DEFAULT NULL,
  `montant` double DEFAULT NULL,
  `devise` varchar(4) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `datesve` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM ;

-- --------------------------------------------------------

--
-- Structure de la table `horaire`
--

DROP TABLE IF EXISTS `horaire`;
CREATE TABLE IF NOT EXISTS `horaire` (
  `idhoraire` int NOT NULL AUTO_INCREMENT,
  `idcours` varchar(50) NOT NULL,
  `id` int NOT NULL,
  `datejour` datetime DEFAULT CURRENT_TIMESTAMP,
  `jourheure` varchar(50) DEFAULT NULL,
  `codemention` varchar(50) DEFAULT NULL,
  `codepromotion` varchar(50) DEFAULT NULL,
  `enseignant` varchar(50) DEFAULT NULL,
  `site` varchar(50) DEFAULT NULL,
  `periode` varchar(50) DEFAULT NULL,
  `observation` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`idhoraire`),
  KEY `idcours` (`idcours`,`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 ;

--
-- Déchargement des données de la table `horaire`
--

INSERT INTO `horaire` (`idhoraire`, `idcours`, `id`, `datejour`, `jourheure`, `codemention`, `codepromotion`, `enseignant`, `site`, `periode`, `observation`) VALUES
(1, 'UML', 0, '2024-09-27 00:00:00', 'VENDREDI-SAMEDI', 'IG', 'L2', 'ASS Messager', ' Vuhima', 'AM', ''),
(2, 'FIAG1', 0, '2024-09-27 00:00:00', 'VENDRE-SAMEDI\r\n8H:OO A 16H30', 'IG', 'L1', 'CT NGURAMO', 'Vuhima', 'AM', 'outil ordinateur est necessaire'),
(3, 'IG1', 0, '0000-00-00 00:00:00', '', '2', 'L1GI', 'E0001', '', 'AM', ''),
(4, 'AL1', 0, '2025-11-12 00:00:00', 'Lundi - Samedi', '2', 'L1GI', 'E0001', 'Vutetse', 'PM', 'bien');

-- --------------------------------------------------------

--
-- Structure de la table `inscription`
--

DROP TABLE IF EXISTS `inscription`;
CREATE TABLE IF NOT EXISTS `inscription` (
  `code_inscription` int NOT NULL AUTO_INCREMENT,
  `matriculeEtudiant` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `codepromotion` varchar(50) NOT NULL,
  `code_mention` int NOT NULL,
  `code_section` int NOT NULL,
  `date_inscription` date NOT NULL,
  `description` varchar(50) NOT NULL,
  PRIMARY KEY (`code_inscription`),
  KEY `matrculetudiant` (`matriculeEtudiant`,`codepromotion`,`code_mention`,`code_section`),
  KEY `matriculeEtudiant` (`matriculeEtudiant`),
  KEY `codepromotion` (`codepromotion`),
  KEY `code_mention` (`code_mention`),
  KEY `code_section` (`code_section`)
) ENGINE=InnoDB AUTO_INCREMENT=2 ;

-- --------------------------------------------------------

--
-- Structure de la table `isp`
--

DROP TABLE IF EXISTS `isp`;
CREATE TABLE IF NOT EXISTS `isp` (
  `code_isp` varchar(50) NOT NULL,
  `dt_creation` date NOT NULL,
  `sigle` varchar(50) NOT NULL,
  `nomComplet` varchar(255) NOT NULL,
  `numArreterminister` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `boitepostal` varchar(50) NOT NULL,
  PRIMARY KEY (`code_isp`)
) ENGINE=InnoDB ;

--
-- Déchargement des données de la table `isp`
--

INSERT INTO `isp` (`code_isp`, `dt_creation`, `sigle`, `nomComplet`, `numArreterminister`, `description`, `boitepostal`) VALUES
('Min-ESU/CAB-234', '2005-11-20', 'ISP-M-B', '  Institut Superieur pedagogic de Muhangi a Butembo', 'Min-ESU/CAB-234', '  Institut Superieur pedagogic de Muhangi a Butembo', 'B.P. 234');

-- --------------------------------------------------------

--
-- Structure de la table `mention`
--

DROP TABLE IF EXISTS `mention`;
CREATE TABLE IF NOT EXISTS `mention` (
  `code_mention` int NOT NULL AUTO_INCREMENT,
  `code_section` int NOT NULL,
  `sigle` varchar(50) NOT NULL,
  `nomComplet` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `dtcreation` date DEFAULT NULL,
  PRIMARY KEY (`code_mention`),
  KEY `code_annee` (`code_section`)
) ENGINE=InnoDB AUTO_INCREMENT=3 ;

--
-- Déchargement des données de la table `mention`
--

INSERT INTO `mention` (`code_mention`, `code_section`, `sigle`, `nomComplet`, `description`, `dtcreation`) VALUES
(2, 2, 'ST', 'SCIENCE ET TECHNOLOGIE', 'SCIENCE ET TECHNOLOGIE', '2010-11-18');

-- --------------------------------------------------------

--
-- Structure de la table `participeraucours`
--

DROP TABLE IF EXISTS `participeraucours`;
CREATE TABLE IF NOT EXISTS `participeraucours` (
  `code` int NOT NULL AUTO_INCREMENT,
  `code_cours` varchar(50) NOT NULL,
  `codepromotion` varchar(50) NOT NULL,
  `matriculeEtudiant` varchar(50) NOT NULL,
  `matriculeEnseignant` varchar(50) NOT NULL,
  `presenceInPercent` double DEFAULT NULL,
  `dtsave` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`code`),
  KEY `code_annee` (`codepromotion`,`code_cours`,`matriculeEtudiant`,`matriculeEnseignant`),
  KEY `matriculeEtudiant` (`matriculeEtudiant`)
) ENGINE=InnoDB AUTO_INCREMENT=4 ;

-- --------------------------------------------------------

--
-- Structure de la table `prestationcours`
--

DROP TABLE IF EXISTS `prestationcours`;
CREATE TABLE IF NOT EXISTS `prestationcours` (
  `id` int NOT NULL AUTO_INCREMENT,
  `codecours` varchar(10) DEFAULT NULL,
  `codeens` varchar(50) DEFAULT NULL,
  `codepromotion` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB ;

-- --------------------------------------------------------

--
-- Structure de la table `promotion`
--

DROP TABLE IF EXISTS `promotion`;
CREATE TABLE IF NOT EXISTS `promotion` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sigle_promotion` varchar(50) NOT NULL,
  `nomComplet` varchar(255) NOT NULL,
  `code_mention` int NOT NULL,
  `description` varchar(255) NOT NULL,
  `dtcreation` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sigle_promotion` (`sigle_promotion`),
  KEY `code_annee` (`code_mention`)
) ENGINE=InnoDB AUTO_INCREMENT=6 ;

--
-- Déchargement des données de la table `promotion`
--

INSERT INTO `promotion` (`id`, `sigle_promotion`, `nomComplet`, `code_mention`, `description`, `dtcreation`) VALUES
(5, 'L1GI', 'Premiere annee de Licence en gesition informatique', 2, 'Premiere annee de Licence en gesition informatique', '2010-11-18');

-- --------------------------------------------------------

--
-- Structure de la table `section`
--

DROP TABLE IF EXISTS `section`;
CREATE TABLE IF NOT EXISTS `section` (
  `code_section` int NOT NULL AUTO_INCREMENT,
  `dt_creation` date NOT NULL,
  `sigle` varchar(50) NOT NULL,
  `nomComplet` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `code_isp` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`code_section`),
  KEY `code_annee` (`code_isp`)
) ENGINE=InnoDB AUTO_INCREMENT=3 ;

--
-- Déchargement des données de la table `section`
--

INSERT INTO `section` (`code_section`, `dt_creation`, `sigle`, `nomComplet`, `description`, `code_isp`) VALUES
(2, '2010-11-20', 'IG', 'Informatique de gestion', 'Informatique de gestion', 'Min-ESU/CAB-234');

-- --------------------------------------------------------

--
-- Structure de la table `utilisateur`
--

DROP TABLE IF EXISTS `utilisateur`;
CREATE TABLE IF NOT EXISTS `utilisateur` (
  `id` int NOT NULL AUTO_INCREMENT,
  `matricule` varchar(50) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` text NOT NULL,
  `role` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `matricule` (`matricule`)
) ENGINE=InnoDB AUTO_INCREMENT=11 ;

--
-- Déchargement des données de la table `utilisateur`
--

INSERT INTO `utilisateur` (`id`, `matricule`, `username`, `password`, `role`) VALUES
(2, 'AAA1', 'christien', '12345678', 'etudiant'),
(3, 'AAA1', 'Christien', '1234567890', 'Etudiant'),
(4, 'AAA1', 'Christien', '1234', 'Chefpromotion'),
(9, 'E0001', 'Somo', '12345', 'Enseignant'),
(10, 'E0002', 'Meno', '123456', 'Chefdesection');

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `inscription`
--
ALTER TABLE `inscription`
  ADD CONSTRAINT `inscription_ibfk_1` FOREIGN KEY (`matriculeEtudiant`) REFERENCES `etudiant` (`matriculeEtudiant`),
  ADD CONSTRAINT `inscription_ibfk_2` FOREIGN KEY (`codepromotion`) REFERENCES `promotion` (`sigle_promotion`),
  ADD CONSTRAINT `inscription_ibfk_3` FOREIGN KEY (`code_mention`) REFERENCES `mention` (`code_mention`),
  ADD CONSTRAINT `inscription_ibfk_4` FOREIGN KEY (`code_section`) REFERENCES `section` (`code_section`);

--
-- Contraintes pour la table `mention`
--
ALTER TABLE `mention`
  ADD CONSTRAINT `mention_ibfk_1` FOREIGN KEY (`code_section`) REFERENCES `section` (`code_section`);

--
-- Contraintes pour la table `participeraucours`
--
ALTER TABLE `participeraucours`
  ADD CONSTRAINT `participeraucours_ibfk_1` FOREIGN KEY (`matriculeEtudiant`) REFERENCES `etudiant` (`matriculeEtudiant`),
  ADD CONSTRAINT `participeraucours_ibfk_2` FOREIGN KEY (`codepromotion`) REFERENCES `promotion` (`sigle_promotion`);

--
-- Contraintes pour la table `promotion`
--
ALTER TABLE `promotion`
  ADD CONSTRAINT `promotion_ibfk_1` FOREIGN KEY (`code_mention`) REFERENCES `mention` (`code_mention`);

--
-- Contraintes pour la table `section`
--
ALTER TABLE `section`
  ADD CONSTRAINT `section_ibfk_1` FOREIGN KEY (`code_isp`) REFERENCES `isp` (`code_isp`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
