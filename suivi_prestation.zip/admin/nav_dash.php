<?php 
    session_start();
    include("../script/config.php");
    
    ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <link href="../layout/styles/layout.css" rel="stylesheet" type="text/css" media="all">
    <title>Document</title>
    
</head>
<body>
    <div class="container">
        <div class="content">
            <h1>
                Dash-board
            </h1>
        </div>

        
    
    
